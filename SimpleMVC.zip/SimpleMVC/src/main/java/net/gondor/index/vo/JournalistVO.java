package net.gondor.index.vo;

public class JournalistVO {
	private int journalistId;
	private String journalistName;
	private String journalistEmail;
	private String company;
	

	public int getJournalistId() {
		return journalistId;
	}
	public void setJournalistId(int journalistId) {
		this.journalistId = journalistId;
	}
	public String getJournalistName() {
		return journalistName;
	}
	public void setJournalistName(String journalistName) {
		this.journalistName = journalistName;
	}
	public String getJournalistEmail() {
		return journalistEmail;
	}
	public void setJournalistEmail(String journalistEmail) {
		this.journalistEmail = journalistEmail;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
}
